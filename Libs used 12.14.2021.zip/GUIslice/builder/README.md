# GUIslice Builder

Drag & drop embedded GUI Builder for GUIslice

## Installation & Operation
For installation and operation instructions, please refer to the following page:
- https://github.com/ImpulseAdventure/GUIslice/wiki/GUIslice-Builder

## Binary Executables
The binary installation executables for the Builder are attached to the latest **GUIslice Builder repo** release notes
(see the dropdown under "Assets"):
- https://github.com/ImpulseAdventure/GUIslice-Builder/releases/

## Source Code
The source code for the GUIslice Builder is maintained in the following repository:
- https://github.com/ImpulseAdventure/GUIslice-Builder

